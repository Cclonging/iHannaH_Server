create definer = root@`%` view view_book as
select `bo`.`book_id`    AS `bookId`,
       `bo`.`book_name`  AS `name`,
       `bo`.`synopsis`   AS `sysnopsis`,
       `bo`.`gmt_create` AS `gmtCreate`,
       `ba`.`auth_name`  AS `author`,
       `bc`.`ca_name`    AS `category`
from ((`hannah`.`book` `bo` left join `hannah`.`book_authory` `ba` on ((`bo`.`author` = `ba`.`auth_id`)))
         left join `hannah`.`book_category` `bc` on ((`bo`.`book_ca_id` = `bc`.`ca_id`)));

-- comment on column view_book.bookId not supported: 小说id

-- comment on column view_book.name not supported: 小说名

-- comment on column view_book.sysnopsis not supported: 简介

-- comment on column view_book.gmtCreate not supported: 创建时间

-- comment on column view_book.author not supported: 作者名


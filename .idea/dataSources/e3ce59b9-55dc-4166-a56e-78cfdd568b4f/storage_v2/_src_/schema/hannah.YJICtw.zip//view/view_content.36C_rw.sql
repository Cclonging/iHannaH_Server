create definer = root@`%` view view_content as
select `cc`.`page_id`      AS `pageId`,
       `cc`.`next_page`    AS `next`,
       `cc`.`chapter_id`   AS `chapterId`,
       `cc`.`page_content` AS `content`
from `hannah`.`chapter_content` `cc`;

